
import streamlit as st

st.set_page_config(page_title="QMS Web App", layout="wide")
st.title("🚀 QMS Streamlit App Online")

st.info("✅ You're running this on Streamlit Cloud!")
st.markdown("This is a basic placeholder. Full QMS features will go here.")
